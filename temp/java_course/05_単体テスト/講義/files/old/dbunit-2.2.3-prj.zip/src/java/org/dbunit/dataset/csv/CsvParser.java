package org.dbunit.dataset.csv;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.List;

import org.dbunit.dataset.csv.handlers.PipelineException;

/**
 * Created By:   fede
 * Date:         10-mar-2004 
 * Time:         15.50.13
 *
 * Last Checkin: $Author: dep4b $
 * Date:         $Date: 2005-05-06 23:04:06 +0200 (ven, 06 mag 2005) $
 * Revision:     $Revision: 480 $
 */
public interface CsvParser {
    List parse(File file) throws IOException, CsvParserException;
    List parse(URL url) throws IOException, CsvParserException;
    List parse(String csv) throws PipelineException, IllegalInputCharacterException;
}
