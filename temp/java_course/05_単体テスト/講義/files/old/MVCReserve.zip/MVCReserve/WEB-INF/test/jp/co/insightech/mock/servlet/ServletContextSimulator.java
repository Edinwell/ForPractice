package jp.co.insightech.mock.servlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;

/**
 * ServletContext �� Simulator �N���X
 * 
 * @author generator
 * @version $Id: ServletContextSimulator.java,v 1.4 2008/05/05 00:10:11 nakajima
 *          Exp $
 */
public class ServletContextSimulator implements ServletContext {

	private Hashtable<String, String> initParameters;

	private Hashtable<String, Object> attributes;

	private RequestDispatcherSimulator dispatcher;

	private File contextDirectory;

	/**
	 * �R���X�g���N�^
	 */
	public ServletContextSimulator() {
		this.dispatcher = null;
		this.initParameters = new Hashtable<String, String>();
		this.attributes = new Hashtable<String, Object>();
	}

	//
	// �������p�����[�^
	//

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletContext#getInitParameter(java.lang.String)
	 */
	public String getInitParameter(String s) {
		return this.initParameters.get(s);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletContext#getInitParameterNames()
	 */
	public Enumeration<String> getInitParameterNames() {
		return this.initParameters.keys();
	}

	/**
	 * �������p�����[�^��ݒ肵�܂�
	 * 
	 * @param key
	 *            �p�����[�^��
	 * @param value
	 *            �p�����[�^�̒l
	 */
	public void setInitParameter(String key, String value) {
		initParameters.put(key, value);
	}

	//
	// ����
	//

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletContext#getAttribute(java.lang.String)
	 */
	public Object getAttribute(String name) {
		return attributes.get(name);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletContext#getAttributeNames()
	 */
	public Enumeration<String> getAttributeNames() {
		return attributes.keys();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletContext#removeAttribute(java.lang.String)
	 */
	public void removeAttribute(String name) {
		attributes.remove(name);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletContext#setAttribute(java.lang.String,
	 *      java.lang.Object)
	 */
	public void setAttribute(String name, Object object) {
		attributes.put(name, object);
	}

	//
	// ���N�G�X�g�f�B�X�p�b�`���[
	//

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletContext#getRequestDispatcher(java.lang.String)
	 */
	public RequestDispatcher getRequestDispatcher(String urlpath) {
		dispatcher = new RequestDispatcherSimulator(urlpath);
		return dispatcher;
	}

	/**
	 * ���N�G�X�g�f�B�X�p�b�`���[���擾���܂�
	 * 
	 * @return ���N�G�X�g�f�B�X�p�b�`���[
	 */
	public RequestDispatcherSimulator getRequestDispatcherSimulator() {
		return dispatcher;
	}

	//
	// ���\�[�X�p�X
	//

	/**
	 * �R���e�L�X�g�f�B���N�g����ݒ肵�܂�
	 * 
	 * @param contextDirectory
	 *            �R���e�L�X�g�f�B���N�g��
	 */
	public void setContextDirectory(File contextDirectory) {
		this.contextDirectory = contextDirectory;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletContext#getRealPath(java.lang.String)
	 */
	public String getRealPath(String path) {
		if (contextDirectory == null || path == null) {
			return null;
		} else {
			return (new File(contextDirectory, path)).getAbsolutePath();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletContext#getResource(java.lang.String)
	 */
	@SuppressWarnings("deprecation")
	public URL getResource(String path) throws MalformedURLException {
		File file = getResourceAsFile(path);
		if (file.exists()) {
			return file.toURL();
		}
		if (!path.startsWith("/")) {
			path = "/" + path;
		}
		return getClass().getResource(path);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletContext#getResourceAsStream(java.lang.String)
	 */
	public InputStream getResourceAsStream(String path) {
		File file = getResourceAsFile(path);
		if (file.exists()) {
			try {
				return new FileInputStream(file);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}

		if (!path.startsWith("/")) {
			path = "/" + path;
		}

		return getClass().getResourceAsStream(path);
	}

	/**
	 * ���\�[�X���t�@�C���Ƃ��Ď擾���܂�
	 * 
	 * @param path
	 *            ���\�[�X�̃p�X
	 * @return ���\�[�X�t�@�C��
	 */
	private File getResourceAsFile(String path) {
		File file = new File(path);
		if (!file.exists()) {
			if (!path.startsWith("/"))
				path = "/" + path;
			if (this.contextDirectory != null)
				file = new File(this.contextDirectory.getAbsolutePath() + path);
			else
				file = new File((new File(".")).getAbsolutePath() + path);
		}
		return file;
	}

	//
	// ���O
	//

	/**
	 * @deprecated Method log is deprecated
	 */
	@Deprecated
	public void log(Exception exception, String msg) {
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletContext#log(java.lang.String)
	 */
	public void log(String msg) {
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletContext#log(java.lang.String,
	 *      java.lang.Throwable)
	 */
	public void log(String message, Throwable throwable) {
	}

	//
	// ������
	//

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletContext#getMajorVersion()
	 */
	public int getMajorVersion() {
		return 2;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletContext#getMinorVersion()
	 */
	public int getMinorVersion() {
		return 3;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletContext#getMimeType(java.lang.String)
	 */
	public String getMimeType(String file) {
		throw new UnsupportedOperationException(
				"getMimeType operation is not supported!");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletContext#getNamedDispatcher(java.lang.String)
	 */
	public RequestDispatcher getNamedDispatcher(String s) {
		throw new UnsupportedOperationException(
				"getNamedDispatcher operation is not supported!");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletContext#getServerInfo()
	 */
	public String getServerInfo() {
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletContext#getServlet(java.lang.String)
	 */
	public Servlet getServlet(String name) throws ServletException {
		throw new UnsupportedOperationException(
				"getServlet operation is not supported!");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletContext#getServletContextName()
	 */
	public String getServletContextName() {
		throw new UnsupportedOperationException(
				"getServletContextName operation is not supported!");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletContext#getServletNames()
	 */
	public Enumeration<?> getServletNames() {
		throw new UnsupportedOperationException(
				"getServletNames operation is not supported!");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletContext#getServlets()
	 */
	public Enumeration<?> getServlets() {
		throw new UnsupportedOperationException(
				"getServlets operation is not supported!");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletContext#getResourcePaths(java.lang.String)
	 */
	public Set<?> getResourcePaths(String path) {
		throw new UnsupportedOperationException(
				"getResourcePaths operation is not supported!");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletContext#getContext(java.lang.String)
	 */
	public ServletContext getContext(String uripath) {
		throw new UnsupportedOperationException(
				"getContext operation is not supported!");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletContext#getContextPath()
	 */
	public String getContextPath() {
		return null;
	}
}
