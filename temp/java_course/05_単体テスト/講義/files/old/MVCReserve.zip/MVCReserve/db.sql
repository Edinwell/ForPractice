create database reserve;

use reserve;

create table USER_TABLE(
   USER_ID varchar(16) PRIMARY KEY,
   USER_NAME varchar(255) NOT NULL
);

create table ROOM_TABLE(
   ROOM_ID integer PRIMARY KEY,
   ROOM_NAME varchar(255) NOT NULL
);

create table RESERVE_TABLE(
   RESERVE_DATE date NOT NULL,
   RESERVE_TIME integer NOT NULL,
   RESERVE_ROOM_ID integer NOT NULL,
   RESERVE_USER_ID varchar(16) NOT NULL
);					

INSERT INTO USER_TABLE Values('0106', '��� �r��');
INSERT INTO USER_TABLE Values('1111', '�� ���q');

INSERT INTO ROOM_TABLE Values('1', '��u��');
INSERT INTO ROOM_TABLE Values('2', '��c��');
INSERT INTO ROOM_TABLE Values('3', '�k�b��');

