package jp.co.insightech;

import java.io.IOException;
import java.sql.Date;
import java.util.Calendar;
import java.util.Vector;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ShowReserveServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {
			HttpSession session = request.getSession();

			Calendar reserveDate = this.getReserveDate(request);

			ReserveDao dao = new ReserveDao();

			Vector roomList = dao.getRoomList();

			request.setAttribute("ROOM_LIST", roomList);

			if (request.getParameter("login") != null) {
				String loginId = request.getParameter("loginId");

				User user = login(loginId);

				if (user == null) {
					request.setAttribute("ERROR_MESSAGE", "���[�UID���Ⴂ�܂�");
				} else {

					session.setAttribute("LOGIN_USER", user);
				}

			} else if (request.getParameter("logout") != null) {
				User user = (User) session.getAttribute("LOGIN_USER");

				request.setAttribute("LOGIN_ID", user.getId());
				session.removeAttribute("LOGIN_USER");

			} else if (request.getParameter("prevMonth") != null) {
				reserveDate.add(Calendar.MONTH, -1);

			} else if (request.getParameter("nextMonth") != null) {
				reserveDate.add(Calendar.MONTH, 1);

			} else if (request.getParameter("today") != null) {
				reserveDate = Calendar.getInstance();

			} else if (request.getParameter("doReserve") != null) {
				User user = (User) session.getAttribute("LOGIN_USER");

				this.doReserve(reserveDate, user, this
						.getReserveDataList(request), this
						.getCancelDataList(request));
			}

			Vector reserveList = dao.getReserveList(reserveDate);

			request.setAttribute("RESERVE_DATE", reserveDate);
			request.setAttribute("RESERVE_LIST", reserveList);

			ServletContext sc = getServletContext();
			RequestDispatcher rd = sc.getRequestDispatcher("/reserve.jsp");
			rd.forward(request, response);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	private Calendar getReserveDate(HttpServletRequest request) {
		Calendar reserveDate = Calendar.getInstance();
		reserveDate.setLenient(false);

		String year = request.getParameter("year");
		String month = request.getParameter("month");
		String day = request.getParameter("day");

		if (year != null && month != null && day != null) {
			reserveDate.set(Calendar.YEAR, Integer.parseInt(year));
			reserveDate.set(Calendar.MONTH, Integer.parseInt(month) - 1);
			reserveDate.set(Calendar.DAY_OF_MONTH, Integer.parseInt(day));
		}

		try {
			reserveDate.getTime();

		} catch (IllegalArgumentException e) {
			reserveDate = Calendar.getInstance();
			reserveDate.setLenient(false);
		}

		return reserveDate;
	}

	public Vector getReserveDataList(HttpServletRequest request) {
		return this.getReserveDataList(request, request
				.getParameterValues("reserveDatas"));
	}

	public Vector getCancelDataList(HttpServletRequest request) {
		return this.getReserveDataList(request, request
				.getParameterValues("cancelDatas"));
	}

	private Vector getReserveDataList(HttpServletRequest request, String[] datas) {
		Vector list = new Vector();

		if (datas != null) {
			for (int i = 0; i < datas.length; i++) {
				String[] args = datas[i].split("_");

				int roomId = Integer.parseInt(args[0]);
				int time = Integer.parseInt(args[1]);

				Reserve reserve = new Reserve();
				reserve.setDate(new Date(this.getReserveDate(request).getTime()
						.getTime()));

				Room room = new Room();
				room.setId(roomId);

				reserve.setRoom(room);
				reserve.setTime(time);

				list.add(reserve);
			}
		}

		return list;
	}

	private User login(String loginId) throws Exception {
		ReserveDao dao = new ReserveDao();

		User user = dao.getUser(loginId);

		return user;
	}

	private void doReserve(Calendar reserveDate, User user,
			Vector reserveDataList, Vector cancelDataList) throws Exception {
		ReserveDao dao = new ReserveDao();

		Vector reserveList = dao.getReserveList(reserveDate);

		for (int i = 0; i < reserveDataList.size(); i++) {
			Reserve reserveData = (Reserve) reserveDataList.get(i);

			Reserve reserve = ReserveUtils.getReserve(reserveData.getTime(),
					reserveData.getRoom().getId(), reserveList);

			if (reserve == null) {
				reserveData.setDate(new Date(reserveDate.getTime().getTime()));
				reserveData.setUser(user);

				dao.register(reserveData);
			}
		}

		for (int i = 0; i < cancelDataList.size(); i++) {
			Reserve reserveData = (Reserve) cancelDataList.get(i);

			Reserve reserve = ReserveUtils.getReserve(reserveData.getTime(),
					reserveData.getRoom().getId(), reserveList);

			if (reserve != null) {
				if (reserve.getUser().getId().equals(user.getId())) {
					reserveData.setDate(new Date(reserveDate.getTime()
							.getTime()));
					reserveData.setUser(user);

					dao.remove(reserveData);
				}
			}
		}

	}
}
