package jp.co.insightech;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.Vector;

public class ReserveDao {

	/**
	 * �w�肳�ꂽ�\����̗\����ꗗ���擾���܂�
	 * 
	 * @param reserveDate
	 *            �\���
	 * @return �\����ꗗ
	 * @throws Exception
	 */
	public Vector getReserveList(Calendar reserveDate) throws Exception {
		Vector reserveList = new Vector();

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = this.getConnection();

			String sql = "SELECT * FROM RESERVE_TABLE WHERE RESERVE_DATE = ?";
			pstmt = conn.prepareStatement(sql);

			Date date = new Date(reserveDate.getTime().getTime());
			pstmt.setDate(1, date);

			rs = pstmt.executeQuery();

			while (rs.next()) {
				Reserve reserve = new Reserve();

				int time = rs.getInt("RESERVE_TIME");
				int roomId = rs.getInt("RESERVE_ROOM_ID");
				String userId = rs.getString("RESERVE_USER_ID");

				User user = new User();
				user.setId(userId);

				Room room = new Room();
				room.setId(roomId);

				reserve.setDate(date);
				reserve.setRoom(room);
				reserve.setTime(time);
				reserve.setUser(user);

				reserveList.add(reserve);
			}

		} finally {
			this.close(rs);
			this.close(pstmt);
			this.close(conn);
		}

		return reserveList;
	}

	/**
	 * �\�����o�^���܂�
	 * 
	 * @param reserve
	 *            �\����
	 * @throws Exception
	 */
	public void register(Reserve reserve) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			conn = this.getConnection();

			pstmt = conn
					.prepareStatement("INSERT INTO RESERVE_TABLE VALUES(?,?,?,?)");

			pstmt.setString(1, reserve.getUser().getId());
			pstmt.setInt(2, reserve.getRoom().getId());
			pstmt.setDate(3, reserve.getDate());
			pstmt.setInt(4, reserve.getTime());

			pstmt.executeUpdate();

		} finally {
			this.close(pstmt);
			this.close(conn);
		}
	}

	/**
	 * �\������폜���܂�
	 * 
	 * @param reserve
	 *            �\����
	 * @throws Exception
	 */
	public void remove(Reserve reserve) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			conn = this.getConnection();

			pstmt = conn
					.prepareStatement("DELETE FROM RESERVE_TABLE WHERE RESERVE_DATE = ? AND RESERVE_TIME = ? AND RESERVE_ROOM_ID = ? AND RESERVE_USER_ID = ?");

			pstmt.setDate(1, reserve.getDate());
			pstmt.setInt(2, reserve.getTime());
			pstmt.setInt(3, reserve.getRoom().getId());
			pstmt.setString(4, reserve.getUser().getId());

			pstmt.executeUpdate();

		} finally {
			this.close(pstmt);
			this.close(conn);
		}
	}
	
	/**
	 * �������ꗗ���擾���܂�
	 * 
	 * @return �������ꗗ
	 * @throws Exception
	 */
	public Vector getRoomList() throws Exception {
		Vector roomList = new Vector();

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = this.getConnection();

			String sql = "SELECT * FROM ROOM_TABLE ORDER BY ROOM_ID";
			pstmt = conn.prepareStatement(sql);

			rs = pstmt.executeQuery();

			while (rs.next()) {
				Room room = new Room();

				int id = rs.getInt("ROOM_ID");
				String name = rs.getString("ROOM_NAME");

				room.setId(id);
				room.setName(name);

				roomList.add(room);
			}

		} finally {
			this.close(rs);
			this.close(pstmt);
			this.close(conn);
		}

		return roomList;
	}

	/**
	 * ���[�U�����擾���܂�
	 * 
	 * @return ���[�U���
	 * @throws Exception
	 */
	public User getUser(String id) throws Exception {
		User user = null;

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = this.getConnection();

			String sql = "SELECT * FROM USER_TABLE WHERE USER_ID = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				user = new User();

				String name = rs.getString("USER_NAME");

				user.setId(id);
				user.setName(name);
			}

		} finally {
			this.close(rs);
			this.close(pstmt);
			this.close(conn);
		}

		return user;
	}

	/**
	 * DB�Ɛڑ����܂�
	 * 
	 * @throws Exception
	 */
	private Connection getConnection() throws Exception {
		Class.forName("org.gjt.mm.mysql.Driver");
		Connection conn = DriverManager
				.getConnection(
						"jdbc:mysql://localhost/RESERVE?useUnicode=true&characterEncoding=MS932",
						"root", "");
		return conn;
	}

	/**
	 * �R�l�N�V������ؒf���܂�
	 * 
	 * @param conn
	 *            �R�l�N�V����
	 * @throws SQLException
	 */
	private void close(Connection conn) throws SQLException {
		if (conn != null) {
			conn.close();
		}
	}

	/**
	 * Statement ��j�����܂�
	 * 
	 * @param stmt
	 *            Statement
	 * @throws SQLException
	 */
	private void close(Statement stmt) throws SQLException {
		if (stmt != null) {
			stmt.close();
		}
	}

	/**
	 * ResultSet ��j�����܂�
	 * 
	 * @param rs
	 *            ResultSet
	 * @throws SQLException
	 */
	private void close(ResultSet rs) throws SQLException {
		if (rs != null) {
			rs.close();
		}
	}

}
