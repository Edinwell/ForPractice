package jp.co.insightech.testcase;

import java.sql.Connection;
import java.sql.DriverManager;

import org.dbunit.Assertion;
import org.dbunit.DatabaseTestCase;
import org.dbunit.database.DatabaseConnection;
import org.dbunit.database.IDatabaseConnection;
import org.dbunit.dataset.Column;
import org.dbunit.dataset.CompositeTable;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.dbunit.dataset.ITableMetaData;
import org.dbunit.dataset.xml.FlatXmlDataSet;
import org.dbunit.operation.DatabaseOperation;

/**
 * <pre>
 * 
 * DBUnit���g�p����ڑ��ݒ��A�e�[�u���̏����ݒ�Ȃǂ��������钊�ۃN���X
 * 
 * Dao�̃e�X�g�P�[�X���쐬����ꍇ�͂��̃N���X���p�����܂��B
 * 
 * </pre>
 */
public abstract class DaoTC extends DatabaseTestCase {

	/** URL */
	private static final String URL = "jdbc:mysql://localhost/bbs?useUnicode=true&characterEncoding=utf8";

	/** Driver */
	private static final String DRIVER = "org.gjt.mm.mysql.Driver";

	/** User */
	private static final String USER = "okameg";

	/** Password */
	private static final String PASSWORD = "okameg";

	/**
	 * �Z�b�g�A�b�v
	 */
	protected void setUp() throws Exception {
		super.setUp();
	}

	/**
	 * �e�B�A�_�E��
	 */
	protected void tearDown() throws Exception {
		super.tearDown();
	}

	/**
	 * �R�l�N�V�������擾���܂��B
	 * 
	 */
	protected IDatabaseConnection getConnection() throws Exception {

		Class.forName(DRIVER);
		Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
		return new DatabaseConnection(conn);

	}
	
	/**
	 * CLEAN_INSERT����
	 * 
	 * @param xmlName
	 *            �Ώ�XML��
	 * @throws Exception
	 */
	protected void cleanInsert(String xmlName) throws Exception {
		IDataSet xmlDataSet = new FlatXmlDataSet(getClass().getResourceAsStream(
				xmlName));
		IDatabaseConnection connection = getConnection();
		DatabaseOperation.CLEAN_INSERT.execute(connection, xmlDataSet);
		if (!connection.getConnection().getAutoCommit()) {
			connection.getConnection().commit();
		}
		closeConnection(connection);
	}
	
	/**
	 * ������XML���擾����
	 * 
	 * @return ������XML���擾�����DataSet
	 * @throws Exception
	 *             ������O
	 */
	@Override
	protected IDataSet getDataSet() throws Exception {
		if (getInitXml() == null) {
			return null;
		}
		return new FlatXmlDataSet(getClass().getResourceAsStream(getInitXml()));
	}
	
	/**
	 * ������XML���擾 Override���A�������Ώۂ�XML�����L�q���邱��
	 * ���AgetClass().getResourceAsStream("name")�ɂĎ擾����̂� �p�X�͕K�v���� ex) return
	 * "init_table.xml";
	 * 
	 * @return ������Ԃ��L�q����XML
	 */
	protected String getInitXml() {
		return null;
	}
	
	/**
	 * �e�X�g���s�i�f�[�^�Z�b�g�P�ʁj
	 * 
	 * @param xmlName
	 *            ���҂���DB��Ԃ̋L�q���ꂽXML
	 * @throws Exception
	 */
	protected void assertDBDataSet(String xmlName) throws Exception {
		IDataSet xmlDataSet = new FlatXmlDataSet(getClass().getResourceAsStream(
				xmlName));
		IDatabaseConnection connection = getConnection();
		IDataSet dbDataSet = connection.createDataSet();

		String[] tableNames = xmlDataSet.getTableNames();
		for (int i = 0; i < tableNames.length; i++) {
			ITable expectTable = xmlDataSet.getTable(tableNames[i]);
			ITable resultTable = dbDataSet.getTable(tableNames[i]);
			// XML�ɖ����J�����͖���
			ITable compositTable = new CompositeTable(expectTable
					.getTableMetaData(), resultTable);
			
			debug(expectTable, compositTable);

			Assertion.assertEquals(expectTable, compositTable);
		}

		closeConnection(connection);
	}
	
	private void debug(ITable expectTable, ITable compositTable) {

		System.out.println("------- expected -------");
		System.out.println(toString(expectTable));
		System.out.println("------- composit -------");
		System.out.println(toString(compositTable));
		
	}

	private String toString(ITable table) {
		StringBuffer buf = new StringBuffer();
		
		try {
		ITableMetaData data = table.getTableMetaData();
		Column[] columns = data.getColumns();
		String[] columnNames = new String[columns.length];
		for (int i = 0; i < columns.length; i++) {
			String name = columns[i].getColumnName();
			columnNames[i] = name;
		}
		
		for (int i = 0; i < table.getRowCount(); i++) {
			buf.append("[");
			buf.append(i);
			buf.append("]");
			for (int j = 0; j < columnNames.length; j++) {
				String columnName = columnNames[j];
				Object o = table.getValue(i, columnName);
				buf.append(columnName);
				buf.append("=");
				buf.append(o.toString());
				buf.append(",");
			}
			buf.deleteCharAt(buf.length()-1);
			buf.append("\r\n");
		}
		
		} catch (Exception e) {
			
		}
		
		return buf.toString();
	}
	

}
